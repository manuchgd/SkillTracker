import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {SearchassociateComponent} from './searchassociate/searchassociate.component';
import { ManageskillComponent } from './manageskill/manageskill.component';
import {ManageassociateComponent} from './manageassociate/manageassociate.component';

const appRoutes:Routes=[
  {path:'',redirectTo:'searchassociate',pathMatch:'full'},
  {path:'searchassociate',component:SearchassociateComponent},
  {path:'manageassociate',component:ManageassociateComponent},
  {path:'manageskill',component:ManageskillComponent}

]
@NgModule({
  imports: [
    RouterModule.forRoot(appRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule { }
