import { Component, OnInit } from '@angular/core';
import { AssociateModel } from '../entities/associate';
import { DropdownItem } from '../entities/dropdownItem';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import {SliderModule} from 'primeng/slider';
import { ConfirmationService, Message } from 'primeng/api';
import { ManageassociateService } from './manageassociate.service';
import { AssociateSkill } from '../entities/associateSkill';
import { AssociateProficiency } from '../entities/associateproficiency';
import { Subscription } from 'rxjs/Subscription';
import { Router, ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-manageassociate',
  templateUrl: './manageassociate.component.html',
  styleUrls: ['./manageassociate.component.css'],
  providers:[ConfirmationService,ManageassociateService]
})
export class ManageassociateComponent implements OnInit {
  msgs: Message[] = [];
  currentStatus:string="Add";
  associate:AssociateModel;
  genders:DropdownItem[]=[{id:1,name:"Male" },{id:2,name:"Female"}]
  form: FormGroup;
  associateSkillRating:AssociateProficiency[];
  associateSkill:AssociateSkill[];
  private sub:Subscription; 
  associateId:number;
  currentView:number=1;
  imgURL:string="";
  constructor(private service:ManageassociateService,private formBuilder: FormBuilder,private confirmationService:ConfirmationService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit() {
    this.sub=this.route.queryParams
    .subscribe(params => {
      // Defaults to 0 if no query param provided.
      // debugger;
      this.associateId = +params['id'] || 0;
      this.currentView=+params['view'] || 1;
      this.initForm();
      if(this.associateId==0)
      {
        this.getAssociateSkill(0);
      }
      else
      {
        this.currentStatus="Edit";
        this.editInit(this.associateId);
        this.getAssociateSkill(this.associateId);
      }
    });
     
    
  }
  initForm()
  {
    this.form = this.formBuilder.group({
      id:[0],
      name: [null,Validators.required],
      associateid: [null, Validators.required], 
      gender: [null, Validators.required],      
      email: [null, Validators.required],
      mobile: [null, Validators.required],
       status:[1],
       level:[1],
        remark:[null],
        others:[null],
        strength:[null],
        weakness:[null],
        pic:""
    });
   
  }
  resetAssociate()
  {
    this.form.patchValue({
      status:[1],
      name:[null],
      id:[0],
      mobile:[null],
      associateid:[null],
      weakness:[null],
      pic:"",
      level:[1],
       gender: [null],
       others:[null],
      email:[null],
      strength:[null],
      remark:[null]
    });
    this.getAssociateSkill(0);
  }
editInit(associateId:number)
{
  this.service.getAssociate(this.associateId)
      .subscribe(data => {
        debugger;
         this.associate = data;
         this.imgURL=data.Pic;
         this.form.patchValue({
          status:this.associate.Status,
          name:this.associate.Name,
          id:this.associate.Id,
          mobile:this.associate.Mobile,
          associateid:this.associate.Associate_ID,
          weakness:this.associate.Weakness,
          pic:this.associate.Pic,
          level:this.associate.Level,
           gender: this.associate.Gender,
           others:this.associate.Others,
          email:this.associate.Email,
          strength:this.associate.Strength,
          remark:this.associate.Remark
        });
        }
        );

}

 getAssociateSkill(associateid:number)
  {
    this.associateSkillRating=[];
    this.service.getAssociateSkills(associateid)
      .subscribe(data => {
         this.associateSkillRating = data; }
        );
  }
  updateStatus(statusValue:number)
  {
    this.form.patchValue({
      status:statusValue
    });
  }
  updateLevel(updateValue:number)
  {
    this.form.patchValue({
      level:updateValue
    });
  }
  SaveAssociate()
  {
    debugger;
    this.associate={
      Id: this.form.get('id').value,
      Name: this.form.get('name').value.toString(),
      Associate_ID: this.form.get('associateid').value.toString(),
      Email: this.form.get('email').value.toString(),
      Gender: this.form.get('gender').value,
      Mobile: this.form.get('mobile').value.toString(),
      Level: this.form.get('level').value,
      Remark:this.form.get('remark').value,
      Strength:this.form.get('strength').value,
      Weakness:this.form.get('weakness').value,
      Status:this.form.get('status').value,
      Others:this.form.get('others').value,
      Pic:this.form.get('pic').value,
      AssociateSkills:this.getAllAssociateSkill()
    };
    

    this.service.updateAssociate(this.associate)
          .subscribe(
          value => {
            this.showMessage(value.ActionStatus,value.Message);
            this.router.navigate(['searchassociate']);

          },
          error => {this.showMessage(false,"Error");});
  }
  getAllAssociateSkill()
  {
    this.associateSkill=[];
    if(this.associateSkillRating.length>0)
    {
      for (let skill of this.associateSkillRating) {
        if(skill.Proficiency>0)
        {
          this.associateSkill.push({
             Id:0,
            Associate_ID:0,
            Skill_ID:skill.SkillId,
            Proficiency:skill.Proficiency
          })
        }
    }
    }
    return this.associateSkill;
  }
  showMessage(status: boolean, message: string) {
    this.msgs = [];
    if (status === true) {
      this.msgs.push({ severity: 'success', summary: "Success", detail: message });
    }
    else {
      this.msgs.push({ severity: 'error', summary: "Error", detail: message });

    }
  }

  changeListener($event) : void {
    this.readThis($event.target);
  }
  
  readThis(inputValue: any): void {
    var file:File = inputValue.files[0];
    var myReader:FileReader = new FileReader();
  
    myReader.onloadend = (e) => {
      this.form.patchValue({
        pic:myReader.result
      });
      this.imgURL=myReader.result;
    }
    
    myReader.readAsDataURL(file);
  }

  DeleteAssociate()
  {
    debugger;
    this.confirmationService.confirm({
      message: 'Do you want to delete this associate?',
      accept: () => {
      this.service.deleteassociate(this.associateId)
            .subscribe(
              
              value => {
                this.showMessage(value.ActionStatus,value.Message);
                this.router.navigate(['searchassociate']);
              },
              error => {this.showMessage(false,"Error");});
            }
          });
  }
}
