// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { ManageassociateComponent } from './manageassociate.component';

// describe('ManageassociateComponent', () => {
//   let component: ManageassociateComponent;
//   let fixture: ComponentFixture<ManageassociateComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ ManageassociateComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(ManageassociateComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
