import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';

import { RequestOptions } from '@angular/http';
import { AssociateModel } from '../entities/associate';
import { Observable } from 'rxjs/Observable';
import { Status } from '../entities/status';
import { Options } from 'selenium-webdriver/chrome';
import { environment } from '../../environments/environment';
import { AssociateProficiency } from '../entities/associateproficiency';
@Injectable()
export class ManageassociateService {
  constructor(private http: HttpClient) {}

  getAllAssociates(): Observable<any[]> {
    return this.http.get<any[]>(environment.apiUrl+"/api/getSearchAssociates");
  }
  updateAssociate(associate:AssociateModel): Observable<Status> {
   
    return this.http.post<Status>(environment.apiUrl+"/api/ManageAssociate",associate);
  }

  deleteassociate(associateId:number): Observable<Status> {
    return this.http.post<Status>(environment.apiUrl+"/api/DeleteAssociate?associateId="+associateId,'');
  }
  getAssociateSkills(associateId:number): Observable<AssociateProficiency[]> {
    return this.http.get<AssociateProficiency[]>(environment.apiUrl+"/api/GetAssociateSkill?associateId="+associateId);
  }
  getAssociate(associateId:number): Observable<AssociateModel> {
    return this.http.get<AssociateModel>(environment.apiUrl+"/api/getAssociateById?associateId="+associateId);
  }
}