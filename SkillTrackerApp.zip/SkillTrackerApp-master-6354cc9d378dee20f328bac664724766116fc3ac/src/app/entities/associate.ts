import { AssociateSkill } from "./associateSkill";

export class AssociateModel{
    Id: number;
    Associate_ID: string;
    Name:string;
    Email:string;
    Mobile:string;
    Pic:string;
    Status:number;
    Level:number;
    Remark:string;
    Others:string;
    Strength:string;
    Weakness:string;
    Gender:number;
    AssociateSkills:AssociateSkill[];

}