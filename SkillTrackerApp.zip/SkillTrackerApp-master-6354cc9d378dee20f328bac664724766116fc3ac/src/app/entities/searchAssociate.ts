export class SearchAssociate
{
    id:number;
    name:string;
    associateid:string;
    statusColor:string;
    pic:string;
    strongSkills:string;
    email:string;
    mobile:string;
}