export class DropdownItem
{
    id:number;
    name:string;
}