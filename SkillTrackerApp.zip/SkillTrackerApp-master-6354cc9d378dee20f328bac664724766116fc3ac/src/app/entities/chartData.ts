export class ChartData{
    Color: string;
    Name: string;
    Id: number;
    AssociateCount: number;
    Width: number;
}