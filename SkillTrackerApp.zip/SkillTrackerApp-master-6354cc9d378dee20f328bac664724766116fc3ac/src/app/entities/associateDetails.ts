import { ChartData } from "./chartData";

export class AssociateDetail
{
    RegistredCandidate:number;
    FemaleCandidate:number;
    MaleCandidate:number;
    FresherCandidate:number;
    RatedCandidate:number;
    FemaleRatedCandidate:number;
    MaleRatedCandidate:number;
    Level1Candidate:number;
    Level3Candidate:number;
    Level2Candidate:number;
    chartData: ChartData[]
}