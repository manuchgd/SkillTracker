export class AssociateSkill{
    Id:number;
    Associate_ID:number;
    Skill_ID:number;
    Proficiency:number;
}