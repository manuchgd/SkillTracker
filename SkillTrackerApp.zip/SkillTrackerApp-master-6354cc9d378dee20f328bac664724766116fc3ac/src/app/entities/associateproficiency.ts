export class AssociateProficiency{
    AssociateId:number;
    SkillId:number;
    SkillName:string;
    Proficiency:number;
}