import { Injectable } from '@angular/core';

export interface Status {
  ActionStatus: boolean;
  Message: string;
}