export interface Skill {
    SkillId: number;
    SkillName: string;
  }