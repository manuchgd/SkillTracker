import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';

import { RequestOptions } from '@angular/http';
import { Skill } from '../entities/skill';
import { Observable } from 'rxjs/Observable';
import { Status } from '../entities/status';
import { Options } from 'selenium-webdriver/chrome';
import { environment } from '../../environments/environment';
@Injectable()
export class ManageskillService {
  constructor(private http: HttpClient) {}

  getAllSkills(): Observable<Skill[]> {
    return this.http.get<Skill[]>(environment.apiUrl+"/api/getAllSkills");
  }
  updateSkill(skill:Skill): Observable<Status> {
   
    return this.http.post<Status>(environment.apiUrl+"/api/updateSkill",skill);
  }
  deleteSkill(skill:Skill): Observable<Status> {
   
    return this.http.post<Status>(environment.apiUrl+"/api/deleteSkill",skill);
  }
}