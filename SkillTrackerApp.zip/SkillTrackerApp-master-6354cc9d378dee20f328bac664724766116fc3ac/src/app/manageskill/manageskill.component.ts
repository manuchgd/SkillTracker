import { Component, OnInit } from '@angular/core';
import { ConfirmationService, Message } from 'primeng/api';
import { ManageskillService } from './manageskill.service';
import { Skill } from '../entities/skill';
import { FormBuilder, FormGroup, Validators,ReactiveFormsModule } from '@angular/forms';
import {DialogModule} from 'primeng/dialog';
import { debug } from 'util';
@Component({
  selector: 'app-manageskill',
  templateUrl: './manageskill.component.html',
  styleUrls: ['./manageskill.component.css'],
  providers:[ConfirmationService,ManageskillService]
})
export class ManageskillComponent implements OnInit {
skillList:Skill[]=[];
public skillData: Skill;
updateSkill: Skill;
updateSkillName :string;
updateSkillId :number;
showDialogue: boolean = false;
msgs: Message[] = [];
form: FormGroup;
  constructor(private confirmationService:ConfirmationService,private service:ManageskillService,private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.form = this.formBuilder.group({
      SkillName: [null,Validators.required]
    });
    this.ResetPage();
  }
  ResetPage()
  {
    this.populateSkills();
    this.skillData ={SkillId:0, SkillName:""};
  }
  populateSkills() {
    this.skillList = [];
    this.service.getAllSkills()
      .subscribe(data => {
        debugger;
         this.skillList = data; });
  }
  UpdateSkill(){
    this.skillList =[];   
    this.service.updateSkill(this.skillData)
          .subscribe(
          value => {
            this.showMessage(value.ActionStatus,value.Message);
            this.ResetPage();
          },
          error => {this.showMessage(false,"Error");});
    
  }
  editSkill(skill:Skill) {
    this.updateSkillName=skill.SkillName;
    this.updateSkillId=skill.SkillId;
    this.showDialogue = true;
  }
  SetUpdateSkill()
  {
    this.updateSkill={ SkillId: this.updateSkillId,SkillName: this.updateSkillName};
  this.showDialogue = false;
  this.skillList =[];   
    this.service.updateSkill(this.updateSkill)
          .subscribe(
          value => {
            this.showMessage(value.ActionStatus,value.Message);
            this.ResetPage();
          },
          error => {this.showMessage(false,"Error");});

  
  }
  DeleteSkill(skill:Skill)
{
  this.confirmationService.confirm({
    message: 'Do you want to delete this skill?',
    accept: () => {
    this.service.deleteSkill(skill)
          .subscribe(
            value => {this.showMessage(value.ActionStatus,value.Message);
              this.ResetPage();
            },
            error => {this.showMessage(false,"Error");});
          }
        });
}
  showMessage(status: boolean, message: string) {
    this.msgs = [];
    if (status === true) {
        this.msgs.push({ severity: 'success', summary: "Success", detail: message });
    }
    else {
        this.msgs.push({ severity: 'error', summary: "Error", detail: message });

    }
}

}
