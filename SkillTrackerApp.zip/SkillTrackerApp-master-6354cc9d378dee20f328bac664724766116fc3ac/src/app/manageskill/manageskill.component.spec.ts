import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageskillComponent } from './manageskill.component';
import { GrowlModule } from 'primeng/growl';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { DialogModule } from 'primeng/dialog';
import { ManageskillService } from './manageskill.service';
import { Skill } from '../entities/skill';
import { Status } from '../entities/status';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ConfirmationService } from 'primeng/api';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Interceptor } from '../Interceptor/Interceptor';
import { DataTableModule } from 'primeng/datatable';
import { SearchassociateComponent } from '../searchassociate/searchassociate.component';
import { ManageassociateComponent } from '../manageassociate/manageassociate.component';
import { RouterTestingModule } from '@angular/router/testing';
describe('ManageskillComponent', () => {
  let component: ManageskillComponent;
  let fixture: ComponentFixture<ManageskillComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageskillComponent ],
      imports:[
        GrowlModule,
        ReactiveFormsModule,
        FormsModule,
        ConfirmDialogModule,
        DialogModule,
        HttpClientModule,
        BrowserAnimationsModule,
        DataTableModule,
        //RouterModule.forRoot(appRoutes),
        RouterTestingModule
      ],
      providers:[
        ManageskillService,
        ConfirmationService,
        {
          provide: HTTP_INTERCEPTORS,
          useClass: Interceptor,
          multi: true
      }

      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageskillComponent);
    component = fixture.componentInstance;
    //fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('get all skills', async(()=> {
    component.populateSkills();
      expect(component.skillList.length).toBeGreaterThanOrEqual(0);
    }
  ));
  it('update skills', async(()=> {
    component.SetUpdateSkill();
      expect(component.skillList.length).toBeGreaterThanOrEqual(0);
    }
  ));
  it('delete skills', async(()=> {
  
    component.DeleteSkill({ SkillId: 1,SkillName: "Test"});
    expect(component.skillList.length).toBeGreaterThanOrEqual(0);
    }
  ));

});
