import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './/app-routing.module';
import { SearchassociateComponent } from './searchassociate/searchassociate.component';
import { ManageskillComponent } from './manageskill/manageskill.component';
import { ManageassociateComponent } from './manageassociate/manageassociate.component';
import {DataTableModule} from 'primeng/datatable';
import {GrowlModule} from 'primeng/growl';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import {DialogModule} from 'primeng/dialog';
import {SliderModule} from 'primeng/slider';

@NgModule({
  declarations: [
    AppComponent,
    SearchassociateComponent,
    ManageskillComponent,
    ManageassociateComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,HttpClientModule,
    BrowserAnimationsModule,
    SliderModule,
    DataTableModule,GrowlModule,ConfirmDialogModule,ReactiveFormsModule,DialogModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
