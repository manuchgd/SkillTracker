import { Component, OnInit } from '@angular/core';
import { ConfirmationService, Message } from 'primeng/api';
import { SearchAssociate } from '../entities/searchAssociate';
import { SearchAssociateService } from './serchassociate.service';
import {DialogModule} from 'primeng/dialog';
import { AssociateDetail } from '../entities/associateDetails';
import { ChartData } from '../entities/chartData';
@Component({
  selector: 'app-searchassociate',
  templateUrl: './searchassociate.component.html',
  styleUrls: ['./searchassociate.component.css'],
  providers:[ConfirmationService,SearchAssociateService]
})
export class SearchassociateComponent implements OnInit {
  msgs: Message[] = [];
  associateList:SearchAssociate[];
  associateDetails:AssociateDetail;
  chartData: ChartData[] = [];
  constructor(private confirmationService:ConfirmationService,private service:SearchAssociateService) { }

  ngOnInit() {
    this.populateAssociateDetails();
    this.populateAssociateList();
  }
  populateAssociateList() {
    this.associateList = [];
    this.service.getAllAssociates()
      .subscribe(data => {
        this.associateList = data;
        
      }
      );
  }
  populateAssociateDetails() {
    this.service.getAssociateDetails()
      .subscribe(data => {
        //debugger;
        this.associateDetails = data;
        this.chartData=data.chartData;
      
      });
  }
  DeleteAssociate(associateId:number)
  {
    
    this.confirmationService.confirm({
      message: 'Do you want to delete this associate?',
      accept: () => {
      this.service.deleteassociate(associateId)
            .subscribe(
              
              value => {
                debugger;
                this.showMessage(value.ActionStatus,value.Message);
                this.populateAssociateList();
              },
              error => {this.showMessage(false,"Error");});
            }
          });
  }
  showMessage(status: boolean, message: string) {
    this.msgs = [];
    if (status === true) {
        this.msgs.push({ severity: 'success', summary: "Success", detail: message });
    }
    else {
        this.msgs.push({ severity: 'error', summary: "Error", detail: message });

    }
}

}
