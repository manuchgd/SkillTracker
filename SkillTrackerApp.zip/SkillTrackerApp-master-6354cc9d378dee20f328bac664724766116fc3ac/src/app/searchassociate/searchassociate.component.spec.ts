// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { SearchassociateComponent } from './searchassociate.component';

// describe('SearchassociateComponent', () => {
//   let component: SearchassociateComponent;
//   let fixture: ComponentFixture<SearchassociateComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ SearchassociateComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(SearchassociateComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
