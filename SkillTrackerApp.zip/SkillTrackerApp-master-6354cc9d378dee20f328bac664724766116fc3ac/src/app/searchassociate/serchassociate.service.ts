import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';

import { RequestOptions } from '@angular/http';
import { SearchAssociate } from '../entities/searchAssociate';
import { Observable } from 'rxjs/Observable';
import { Status } from '../entities/status';
import { Options } from 'selenium-webdriver/chrome';
import { environment } from '../../environments/environment';
import { AssociateDetail } from '../entities/associateDetails';
@Injectable()
export class SearchAssociateService {
  constructor(private http: HttpClient) {}

  getAllAssociates(): Observable<SearchAssociate[]> {
    return this.http.get<SearchAssociate[]>(environment.apiUrl+"/api/getAssociateGridList");
  }
  
  deleteassociate(associateId:number): Observable<Status> {
    return this.http.post<Status>(environment.apiUrl+"/api/DeleteAssociate?associateId="+associateId,'');
  }
  getAssociateDetails()
  {
    return this.http.get<AssociateDetail>(environment.apiUrl+"/api/getAssociateDetails");
  }
}