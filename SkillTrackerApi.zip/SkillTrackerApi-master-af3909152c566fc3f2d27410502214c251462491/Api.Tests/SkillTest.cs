﻿using Api.Controllers;
using Entities;
using Newtonsoft.Json;
using NUnit.Framework;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Api.Tests
{
    [TestFixture]
    public class SkillTest
    {
        public static IEnumerable GetSkillTestData
        {
            get
            {
                string skillData = @"TestFolder\Skill.json";
                string rootPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().CodeBase).Replace("file:\\", "").Replace("\\bin\\Debug", "");

                var jsonText = File.ReadAllText(Path.Combine(rootPath, skillData));
                var addSkill = JsonConvert.DeserializeObject<List<SkillModel>>(jsonText);
                yield return addSkill;
            }
        }

        [Test, TestCaseSource("GetSkillTestData")]
        public void AddSkill(List<SkillModel> lstSkills)
        {
            SkillController oSkillController = new SkillController();
            foreach (SkillModel oSkill in lstSkills)
            {
                Status oStatus1 = oSkillController.Post(oSkill);
                Assert.AreEqual(true, oStatus1.ActionStatus);
            }
            lstSkills= oSkillController.Get().ToList();
            Assert.NotNull(lstSkills);
            SkillModel oSkill1 = new SkillModel() { SkillId = lstSkills[0].SkillId, SkillName = lstSkills[0].SkillName + " New" };
            Status oStatus = oSkillController.Post(oSkill1);
            oStatus= oSkillController.DeleteSkill(oSkill1);
            Assert.IsNotNull(oStatus);

        }
    }
}
