﻿using Api.Controllers;
using Entities;
using Newtonsoft.Json;
using NUnit.Framework;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Api.Tests
{
   public class AssociateTest
    {
        public static IEnumerable GetAssociateData
        {
            get
            {
                string skillData = @"TestFolder\Associate.json";
                string rootPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().CodeBase).Replace("file:\\", "").Replace("\\bin\\Debug", "");

                var jsonText = File.ReadAllText(Path.Combine(rootPath, skillData));
                var addSkill = JsonConvert.DeserializeObject<AssociateModel>(jsonText);
                yield return addSkill;
            }
        }
        [Test, TestCaseSource("GetAssociateData")]
        public void AddAssociate(AssociateModel oSkill)
        {
            AssociateController oControl = new AssociateController();

            Status oStatus = oControl.Post(oSkill);
            Assert.IsNotNull(oStatus);
            List<AssociateListModel> lstAssociate= oControl.Get().ToList();
            Assert.IsNotNull(lstAssociate);
            AssociateModel oModel= oControl.GetAssociateById(lstAssociate[0].Id);
            Assert.IsNotNull(oModel);
            oModel.Name = oModel.Name + " New";
            oStatus = oControl.Post(oSkill);
            Assert.IsNotNull(oStatus);
            Assert.IsNotNull( oControl.GetAssociateSkill(oModel.Id));
            Assert.IsNotNull(oControl.GetAssociateDetails());
            Assert.IsNotNull(oControl.DeleteAssociate(oModel.Id));
         

        }

    }
}
