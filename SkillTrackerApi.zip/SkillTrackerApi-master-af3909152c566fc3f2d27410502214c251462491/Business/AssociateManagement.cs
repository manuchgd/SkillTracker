﻿using DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
namespace Business
{
    public class AssociateManagement
    {
        SkillTrackerRepository oSkillRepo = new SkillTrackerRepository();
        public List<AssociateListModel> GetAssociateList()
        {
            var lst = oSkillRepo.ListAssociates();
            return oSkillRepo.ListAssociates()
                .Select(x => new AssociateListModel
                {
                    Id = x.Id,
                    Associate_ID = x.Associate_ID,
                    Email = x.Email,
                    Mobile = x.Mobile,
                    Name = x.Name,
                    Pic = x.Pic,
                    StatusColor = GetColor(x.Status.Value),
                    StrongSkills = x.AssociateSkills.Count == 0 ? "" : x.AssociateSkills.Select(y => y.Skill.Skill_Name).Aggregate((a, b) => a + "," + b).TrimEnd(',')
                }).ToList();

        }
        private string GetColor(int status)
        {
            if (status == 1)
                return "green";
            else if (status == 2)
                return "blue";
            else
                return "red";
        }
        public List<AssociateSkillProficiency> GetAssociateSkill(int id)
        {
            return oSkillRepo.ListAssociatesProficiency(id);

        }
        public AssociateModel GetAssociateById(int id)
        {
            return oSkillRepo.GetAssociatesById(id);

        }
        public Status ManageAssociate(AssociateModel oAssociate)
        {
            Associate newAssociate = new Associate()
            {
                Id = oAssociate.Id,
                Associate_ID = oAssociate.Associate_ID,
                Email = oAssociate.Email,
                Name = oAssociate.Name,
                Gender = oAssociate.Gender,
                Level = oAssociate.Level,
                Mobile = oAssociate.Mobile,
                Pic = oAssociate.Pic,
                Remark = oAssociate.Remark,
                Status = oAssociate.Status,
                Strength = oAssociate.Strength,
                Weakness = oAssociate.Weakness,
                Others = oAssociate.Others,
                AssociateSkills = oAssociate.AssociateSkills?.Select(x => new AssociateSkill { AssociateId = oAssociate.Id, Skill_ID = x.Skill_ID, Proficiency = x.Proficiency }).ToList()
            };

            return oSkillRepo.ManageAssociate(newAssociate);
        }
        public Status DeleteAssociate(int associateId)
        {
            return oSkillRepo.DeleteAssociate(associateId);
        }
        public AssociateDetails GetAssociateDetails()
        {
            AssociateDetails detail= oSkillRepo.GetAssociateDetails();
            detail.chartData = GetChartdata();
            return detail;
        }

        public List<ChartData> GetChartdata()
        {
            List<string> colorCodes = new List<string>() { "green", "orange", "cyan", "red", "yellow", "grey", "pink", "black", "blue" };
            List<ChartData> graphSkills = new List<ChartData>();
            List<ChartSkill> chartSkills = oSkillRepo.GetChartskill();
            foreach (var ob in chartSkills)
            {
                ChartData o = new ChartData();
                o.Id = ob.Skill_Id;
                o.Name = ob.Skill_Name;
                o.AssociateCount = ob.AssociateCount;
                graphSkills.Add(o);
            }
            int i = 0;
            foreach (var it in graphSkills)
            {
                it.Color = colorCodes[i];
                i++;
                if (i >= colorCodes.Count - 1)
                    i = 0;
            }
            
            List<int> decimalData =oSkillRepo.CalculateWidthPercentage(graphSkills);
            for (i = 0; i < decimalData.Count && i < graphSkills.Count; i++)
            {
                graphSkills[i].Width = decimalData[i];
            }

            return graphSkills;
        }
    }
}
