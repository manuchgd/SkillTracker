﻿using DataAccess;
using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business
{
   public class SkillManagement
    {
        SkillTrackerRepository oSkillRepo = new SkillTrackerRepository();
        public List<SkillModel> GetAllSkills()
        {
          return  oSkillRepo.GetAllSkills().
                Select(x => new SkillModel { SkillId = x.Skill_Id, SkillName = x.Skill_Name }).ToList();

        }
        public Status AddSkill(SkillModel oSkill)
        {
           Skill newSkill= oSkillRepo.ManageSkill(new Skill() { Skill_Id = oSkill.SkillId, Skill_Name = oSkill.SkillName });

            if(newSkill!=null)
            {
                return new Status() { ActionStatus=true, Message= oSkill.SkillId==null?"Skill added successfully":"Skill updated successfully" };
            }
            else
            {
                return new Status() { ActionStatus = false, Message = "Skill addition failed" };
            }

        }
        public Status DeleteSkill(SkillModel oSkill)
        {
            try
            {
                oSkillRepo.DeleteSkill(new Skill()
                {
                    Skill_Id = oSkill.SkillId
                });
                return new Status() { Message = "Skill deleted successfully", ActionStatus = true };
            }
            catch(Exception ex)
            {
                return new Status() { Message = "Skill is assigned to associates please delete assigned skill from associate before deleting selected skill", ActionStatus = false };
            }
        }
    }
}
