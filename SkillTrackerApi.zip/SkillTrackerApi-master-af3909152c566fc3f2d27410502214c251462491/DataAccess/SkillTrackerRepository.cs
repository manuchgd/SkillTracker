﻿using Entities;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess
{
   public class SkillTrackerRepository
    {
        #region Skill
        public List<Skill> GetAllSkills()
        {
            using (var context = new SkillTrackerContext())
            {
                return context.Skills.ToList();
            }
        }
        public Skill ManageSkill(Skill oSkill)
        {
            using (var context = new SkillTrackerContext())
            {
                if(oSkill.Skill_Id!=0)
                {
                    context.Skills.Attach(oSkill);
                    context.Entry(oSkill).State = EntityState.Modified;
                }
                else
                {
                    context.Skills.Add(oSkill);
                }
                context.SaveChanges();
                return oSkill;
            }
        }
        public bool DeleteSkill(Skill oSkill)
        {
            using (var context = new SkillTrackerContext())
            {
                oSkill = context.Skills.FirstOrDefault(x => x.Skill_Id == oSkill.Skill_Id);
                context.Skills.Remove(oSkill);
                context.SaveChanges();
                return true;
            }
        }
        #endregion
        #region Associate
        public List<Associate> ListAssociates()
        {
            using (var context = new SkillTrackerContext())
            {
                return context.Associates.Include(x=>x.AssociateSkills).Include(x=>x.AssociateSkills.Select(y=>y.Skill)).ToList();
            }
        }
        public List<AssociateSkillProficiency> ListAssociatesProficiency(int id)
        {
            using (var context = new SkillTrackerContext())
            {
                return (from s in context.Skills
                        from a in context.AssociateSkills.Where(x => x.AssociateId == id && x.Skill_ID == s.Skill_Id).DefaultIfEmpty()
                        select new AssociateSkillProficiency
                        {
                            AssociateId = a != null ? a.AssociateId : null,
                            Proficiency = a != null ? a.Proficiency.Value : 0,
                            SkillId = s.Skill_Id,
                            SkillName = s.Skill_Name
                        }).AsNoTracking().ToList();
            }
        }

        public AssociateModel GetAssociatesById(int id)
        {
            using (var context = new SkillTrackerContext())
            {
               return context.Associates.Where(x => x.Id == id).Select(x => new AssociateModel
                {
                    Id = x.Id,
                    Associate_ID = x.Associate_ID,
                    Email = x.Email,
                    Gender = x.Gender.Value,
                    Level = x.Level,
                    Status = x.Status,
                    Mobile = x.Mobile,
                    Name = x.Name,
                    Others = x.Others,
                    Pic = x.Pic,
                    Remark = x.Remark,
                    Strength = x.Strength,
                    Weakness = x.Weakness

                }).FirstOrDefault();
            }
        }
        public Status ManageAssociate(Associate oAssociate)
        {
            using (var context = new SkillTrackerContext())
            {
                if (oAssociate.Id != 0)
                {
                    if(context.Associates.Any(x=>x.Associate_ID==oAssociate.Associate_ID &&x.Id!=oAssociate.Id))
                    {
                        return new Status() { ActionStatus = false, Message = "The given Associate ID is already exist" };
                    }
                    context.AssociateSkills.RemoveRange(context.AssociateSkills.Where(x => x.AssociateId == oAssociate.Id));
                    context.SaveChanges();
                    List<AssociateSkill> skils = oAssociate.AssociateSkills.ToList();
                    oAssociate.AssociateSkills = null;
                    context.Associates.Attach(oAssociate);
                    context.Entry(oAssociate).State = EntityState.Modified;
                    context.SaveChanges();
                    skils.ForEach(x => { x.AssociateId = oAssociate.Id; });
                    context.AssociateSkills.AddRange(skils);
                }
                else
                {
                    if (context.Associates.Any(x => x.Associate_ID == oAssociate.Associate_ID ))
                    {
                        return new Status() { ActionStatus = false, Message = "The given Associate ID is already exist" };
                    }
                    context.Associates.Add(oAssociate);
                }
                context.SaveChanges();
                return new Status() { ActionStatus = true, Message =oAssociate.Id==0? "New associate added successfully"
                    :"Associate detail updated succesfully" };
            }
        }

        public Status DeleteAssociate(int id)
        {
            using (var context = new SkillTrackerContext())
            {
                context.AssociateSkills.RemoveRange(context.AssociateSkills.Where(x => x.AssociateId == id));
                context.SaveChanges();
                context.Associates.Remove(context.Associates.FirstOrDefault(x => x.Id == id));
                context.SaveChanges();
                return new Status()
                {
                    ActionStatus = true,
                    Message = "Associate deleted succesfully"
                };
            }
        }
        public AssociateDetails GetAssociateDetails()
        {
            using (var context = new SkillTrackerContext())
            {
                AssociateDetails oDetail = new AssociateDetails();
                oDetail.RegistredCandidate = context.Associates.Count();
                if (oDetail.RegistredCandidate > 0)
                {
                    oDetail.FemaleCandidate = Convert.ToInt32(Math.Round((context.Associates.Where(x => x.Gender == 2).Count() / (float)oDetail.RegistredCandidate) * 100));
                    oDetail.MaleCandidate = Convert.ToInt32(Math.Round(context.Associates.Where(x => x.Gender == 1).Count() / (float)oDetail.RegistredCandidate) * 100);
                    oDetail.FresherCandidate = oDetail.Level1Candidate = Convert.ToInt32(Math.Round(context.Associates.Where(x => x.Level == 1).Count() / (float)oDetail.RegistredCandidate) * 100);
                    oDetail.Level2Candidate = Convert.ToInt32(Math.Round(context.Associates.Where(x => x.Level == 2).Count() / (float)oDetail.RegistredCandidate) * 100);
                    oDetail.Level3Candidate = Convert.ToInt32(Math.Round(context.Associates.Where(x => x.Level == 3).Count() / (float)oDetail.RegistredCandidate) * 100);
                    var rated = context.AssociateSkills.Select(x => x.AssociateId).Distinct();
                    oDetail.RatedCandidate = Convert.ToInt32(Math.Round(rated.Count() / (float)oDetail.RegistredCandidate) * 100);

                    oDetail.MaleRatedCandidate = Convert.ToInt32(Math.Round(context.Associates.Where(x => rated.Contains(x.Id)).Where(x => x.Gender == 1).Count() / (float)oDetail.RegistredCandidate) * 100);
                    oDetail.FemaleRatedCandidate = Convert.ToInt32(Math.Round((oDetail.RatedCandidate - oDetail.MaleRatedCandidate) / (float)oDetail.RegistredCandidate) * 100);
                }
                else
                {
                    oDetail.FemaleCandidate = 0;
                    oDetail.MaleCandidate = 0;
                    oDetail.FresherCandidate = 0;
                    oDetail.Level2Candidate = 0;
                    oDetail.Level3Candidate = 0;
                    oDetail.RatedCandidate = 0;
                    oDetail.MaleRatedCandidate = 0;
                    oDetail.FemaleRatedCandidate = 0;


                }
                return oDetail;   
            }
        }
        public List<ChartSkill> GetChartskill()
        {
            using (var context = new SkillTrackerContext())
            {
              return  (from askil in context.AssociateSkills
                 from sk in context.Skills.Where(x => x.Skill_Id == askil.Skill_ID)
                 group askil.AssociateId by new { sk.Skill_Name, askil.Skill_ID } into grp
                 select new ChartSkill { Skill_Id = grp.Key.Skill_ID.Value, Skill_Name = grp.Key.Skill_Name, AssociateCount = grp.Count() }
                ).ToList();
            }
        }
        public List<int> CalculateWidthPercentage(List<ChartData> skills)
        {
            using (var context = new SkillTrackerContext())
            {
                List<int> skillRatingTotals = new List<int>();
                int ratingTotalForEachSkill = 0;
                int total = 0;
                foreach (var skill in skills)
                {
                    var lstPoficiency = context.AssociateSkills.Where(x => x.Skill_ID == skill.Id)
                        .Select(y => y.Proficiency).ToList();
                    List<int> intRate = new List<int>();
                    foreach (var rate in lstPoficiency)
                    {
                        int i = 0;
                        i = (int)rate;
                        intRate.Add(i);
                    }
                    intRate.ForEach(x =>
                        ratingTotalForEachSkill = ratingTotalForEachSkill + x
                    );
                    total = total + ratingTotalForEachSkill;
                    skillRatingTotals.Add(ratingTotalForEachSkill);
                }
                List<int> widthPercentage = new List<int>();
                int d = 0;
                skillRatingTotals.ForEach(x =>
                {
                    d = (int)((100 * x) / total);
                    widthPercentage.Add(d);
                });
                return widthPercentage;
            }
        }
        #endregion
    }
}
