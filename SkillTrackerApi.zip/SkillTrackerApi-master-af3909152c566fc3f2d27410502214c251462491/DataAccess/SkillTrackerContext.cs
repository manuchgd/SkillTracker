namespace DataAccess
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class SkillTrackerContext : DbContext
    {
        public SkillTrackerContext()
            : base("name=SkillTrackerContext")
        {
            Configuration.LazyLoadingEnabled = false;
        }

        public virtual DbSet<Associate> Associates { get; set; }
        public virtual DbSet<AssociateSkill> AssociateSkills { get; set; }
        public virtual DbSet<Skill> Skills { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
        }
    }
}
