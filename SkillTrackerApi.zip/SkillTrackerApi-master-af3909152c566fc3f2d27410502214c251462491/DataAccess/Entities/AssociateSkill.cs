namespace DataAccess
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("AssociateSkill")]
    public partial class AssociateSkill
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        public int? AssociateId { get; set; }

        public int? Skill_ID { get; set; }

        public int? Proficiency { get; set; }

        public virtual Associate Associate { get; set; }

        public virtual Skill Skill { get; set; }
    }
}
