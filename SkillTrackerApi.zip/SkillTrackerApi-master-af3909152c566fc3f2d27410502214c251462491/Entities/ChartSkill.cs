﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
   public class ChartSkill
    {
       
        public int Skill_Id { get; set; }
        public string Skill_Name { get; set; }

        public int AssociateCount { get; set; }
    }

    
}
