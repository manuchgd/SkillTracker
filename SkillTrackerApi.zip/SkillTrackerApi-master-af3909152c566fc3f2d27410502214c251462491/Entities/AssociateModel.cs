﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
   public class AssociateModel
    {
        public int Id { get; set; }
        public int Associate_ID { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public string Pic { get; set; }
        public int? Status { get; set; }
        public int? Level { get; set; }
        public string Remark { get; set; }
        public string Strength { get; set; }
        public string Weakness { get; set; }
        public string Others { get; set; }
        public int Gender { get; set; }
        public List<AssociateSkillModel> AssociateSkills { get; set; }
    }
}
