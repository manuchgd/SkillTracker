﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
   public class AssociateSkillModel
    {
        public int Id { get; set; }

        public int Associate_ID { get; set; }

        public int Skill_ID { get; set; }

        public int Proficiency { get; set; }
    }
}
