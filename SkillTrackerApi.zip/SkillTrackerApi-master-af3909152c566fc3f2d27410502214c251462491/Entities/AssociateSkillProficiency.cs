﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class AssociateSkillProficiency
    {

        public int? AssociateId { get; set; }

        public int SkillId { get; set; }

        public string SkillName { get; set; }
        public int Proficiency { get; set; }
    }
}
