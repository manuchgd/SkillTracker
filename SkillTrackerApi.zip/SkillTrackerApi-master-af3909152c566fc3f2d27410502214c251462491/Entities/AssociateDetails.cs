﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class AssociateDetails
    {
        public int RegistredCandidate { get; set; }
        public int FemaleCandidate { get; set; }
        public int MaleCandidate { get; set; }
        public int FresherCandidate { get; set; }
        public int RatedCandidate { get; set; }
        public int FemaleRatedCandidate { get; set; }
        public int MaleRatedCandidate { get; set; }
        public int Level1Candidate { get; set; }
        public int Level3Candidate { get; set; }
        public int Level2Candidate { get; set; }
       public  List<ChartData> chartData { get; set; }
    }
}
