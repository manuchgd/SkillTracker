﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class AssociateListModel
    {
        public int Id { get; set; }
        public int Associate_ID { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public string Pic { get; set; }
        public string StatusColor { get; set; }
        public string StrongSkills { get; set; }
    }
}
