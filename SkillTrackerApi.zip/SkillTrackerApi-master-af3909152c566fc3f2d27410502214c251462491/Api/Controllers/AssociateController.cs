﻿using Business;
using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Api.Controllers
{
    public class AssociateController : ApiController
    {
        AssociateManagement oAM = new AssociateManagement();
        [HttpGet]
        [Route("api/getAssociateGridList")]
        public IEnumerable<AssociateListModel> Get()
        {
            return oAM.GetAssociateList();
        }
        [HttpGet]
        [Route("api/getAssociateSkill")]
        public IEnumerable<AssociateSkillProficiency> GetAssociateSkill(int associateId)
        {
            return oAM.GetAssociateSkill(associateId);
        }
        [HttpPost]
        [Route("api/ManageAssociate")]
        public Status Post(AssociateModel oAssociate)
        {
            return oAM.ManageAssociate(oAssociate);

        }
        [HttpGet]
        [Route("api/getAssociateById")]
        public AssociateModel GetAssociateById(int associateId)
        {
            return oAM.GetAssociateById(associateId);
        }
        [HttpPost]
        [Route("api/DeleteAssociate")]
        public Status DeleteAssociate([FromUri]int associateId)
        {
            return oAM.DeleteAssociate(associateId);

        }
        [HttpGet]
        [Route("api/getAssociateDetails")]
        public AssociateDetails GetAssociateDetails()
        {
            return oAM.GetAssociateDetails();
        }
    }
}
