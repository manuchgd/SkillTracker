﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Business;
using Entities;
namespace Api.Controllers
{
    public class SkillController : ApiController
    {
        SkillManagement oSM = new SkillManagement();
        [HttpGet]
        [Route("api/getAllSkills")]
        public IEnumerable<SkillModel> Get()
        {
            return oSM.GetAllSkills();
        }
        [HttpPost]
        [Route("api/updateSkill")]
        public Status Post(SkillModel oSkill)
        {
            return oSM.AddSkill(oSkill);

        }
        [HttpPost]
        [Route("api/deleteSkill")]
        public Status DeleteSkill(SkillModel skill)
        {
            return oSM.DeleteSkill(skill);
        }
    } 
}
